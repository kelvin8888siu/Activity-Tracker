package ActivityTracker.DAO;

import ActivityTracker.model.ActivitySummary;

import java.sql.*;
import java.time.ZoneOffset;
import java.util.ArrayList;

import ActivityTracker.model.*;

public class ActivitySummaryDao {

    protected ConnManager connectionManager;
    private static ActivitySummaryDao instance = null;
    public ActivitySummaryDao() {
        connectionManager = new ConnManager();
    }
    public static ActivitySummaryDao getInstance() {
        if(instance == null) {
            instance = new ActivitySummaryDao();
        }
        return instance;
    }

    public ActivitySummary create(ActivitySummary as) throws SQLException {
        String insertAS = "INSERT INTO Activity_Summary(summaryId," +
                "activity, duration, distance, calories, steps) VALUES (?,?,?,?,?,?);";
        Connection connection = null;
        PreparedStatement insertStmt = null;
        try {
            connection = connectionManager.getConnection();
            insertStmt = connection.prepareStatement(insertAS);
            insertStmt.setInt(1, as.getSummaryId());

            insertStmt.setString(2, as.getActivity());
            insertStmt.setFloat(3, as.getDuration());
            insertStmt.setFloat(4, as.getDistance());
            insertStmt.setFloat(5, as.getCalories());
            insertStmt.setInt(6, as.getSteps());
            insertStmt.executeUpdate();
            return as;
        } catch(SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (insertStmt != null) {
                insertStmt.close();
            }
        }
    }

    public ArrayList<ActivitySummary> getAllActivitySummary() throws SQLException {
        String selectStmt = "SELECT * FROM Activity_Summary " +
                "INNER JOIN Summary " +
                "ON Summary.summaryId = Activity_Summary.SummaryId;";
        Connection connection = null;
        PreparedStatement select = null;
        ResultSet result = null;
        try {
            connection = connectionManager.getConnection();
            select = connection.prepareStatement(selectStmt);
            result = select.executeQuery();
            ArrayList<ActivitySummary> asList = new ArrayList<ActivitySummary>();
            while (result.next()) {
                int activitySummaryId = result.getInt("activity_SummaryId");
                int summaryId = result.getInt("Summary.summaryId");

                String activity = result.getString("activity");
                float duration = result.getFloat("duration");
                float distance = result.getFloat("distance");
                float calories = result.getFloat("calories");
                int steps = result.getInt("steps");
                Date date = result.getDate("Summary.date");
                ActivitySummary as = new ActivitySummary(activitySummaryId, summaryId,
                        activity, duration, distance, calories, steps);
                as.setDate(date.toLocalDate());
                asList.add(as);

            }
            return asList;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (select != null) {
                select.close();
            }
            if (result != null) {
                result.close();
            }
        }
    }

    public ArrayList<ActivitySummary> getActivitySummaryByDate(Date date) throws  SQLException {
        String selectStmt = "SELECT * FROM Activity_Summary " +
                "INNER JOIN Summary " +
                "ON Activity_Summary.SummaryId = Summary.SummaryId " +
                "WHERE Summary.date = ?;";
        Connection connection = null;
        PreparedStatement select = null;
        ResultSet result = null;
        ArrayList<ActivitySummary> asList = new ArrayList<ActivitySummary>();
        try {
            connection = connectionManager.getConnection();
            select = connection.prepareStatement(selectStmt);
            select.setDate(1, date);
            result = select.executeQuery();
            while (result.next()) {
                int activitySummaryId = result.getInt("activity_summaryId");
                int summaryId = result.getInt("Activity_Summary.summaryId");

                String activity = result.getString("activity");
                float duration = result.getFloat("duration");
                float distance = result.getFloat("distance");
                float calories = result.getFloat("calories");
                int steps = result.getInt("steps");
                ActivitySummary as = new ActivitySummary(activitySummaryId, summaryId,
                        activity, duration, distance, calories, steps);
                asList.add(as);
            }
            return asList;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (select != null) {
                select.close();
            }
            if (result != null) {
                result.close();
            }
        }
    }

    public ArrayList<ActivitySummary> getSpecificActivitySummaryByDate(Date date, String activity) throws SQLException {
        String selectStmt = "SELECT * FROM Activity_Summary " +
                "INNER JOIN Summary " +
                "ON Activity_Summary.SummaryId = Summary.SummaryId " +
                "WHERE Summary.date = ? AND Activity_Summary.activity = ?;";
        Connection connection = null;
        PreparedStatement select = null;
        ResultSet result = null;
        ArrayList<ActivitySummary> asList = new ArrayList<ActivitySummary>();
        try {
            connection = connectionManager.getConnection();
            select = connection.prepareStatement(selectStmt);
            select.setDate(1, date);
            select.setString(2, activity);
            result = select.executeQuery();
            while (result.next()) {
                int activitySummaryId = result.getInt("activity_SummaryId");
                int summaryId = result.getInt("Activity_Summary.summaryId");
                String resActivity = result.getString("activity");
                float duration = result.getFloat("duration");
                float distance = result.getFloat("distance");
                float calories = result.getFloat("calories");
                int steps = result.getInt("steps");
                ActivitySummary as = new ActivitySummary(activitySummaryId, summaryId,
                        resActivity, duration, distance, calories, steps);
                asList.add(as);
            }
            return asList;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (select != null) {
                select.close();
            }
            if (result != null) {
                result.close();
            }
        }
    }

    public void delete(int s) throws SQLException {
        String delete = "DELETE FROM Activity_Summary WHERE SummaryId = ?;";
        Connection connection = null;
        PreparedStatement deleteStmt = null;
        try {
            connection = connectionManager.getConnection();
            deleteStmt = connection.prepareStatement(delete);
            deleteStmt.setInt(1, s);
            deleteStmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (deleteStmt != null) {
                deleteStmt.close();
            }
        }
    }
}
