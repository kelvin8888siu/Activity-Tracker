package ActivityTracker.DAO;

import ActivityTracker.model.Records;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;

public class RecordsDao {
    protected ConnManager connectionManager;
    private static RecordsDao instance = null;

    public RecordsDao() {
        connectionManager = new ConnManager();
    }

    public static RecordsDao getInstance() {
        if (instance == null) {
            instance = new RecordsDao();
        }
        return instance;
    }

    public Records create(Records record) throws SQLException {
        String insertRecord = "INSERT INTO Records(date, calorieIdle, lastUpdate) VALUES(?,?,?);";
        Connection connection = null;
        PreparedStatement insertStmt = null;
        try {
            connection = connectionManager.getConnection();
            insertStmt = connection.prepareStatement(insertRecord);
            insertStmt.setDate(1, Date.valueOf(record.getDate()));
            insertStmt.setInt(2, record.getCalorieIdle());
            insertStmt.setDate(3, Date.valueOf(record.getLastupdated()));
            insertStmt.executeUpdate();
            return record;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (insertStmt != null) {
                insertStmt.close();
            }
        }
    }

    public ArrayList<Records> getAllRecords() throws SQLException {
        String selectStmt = "SELECT * FROM Records;";
        Connection connection = null;
        PreparedStatement select = null;
        ResultSet result = null;

        try {
            connection = connectionManager.getConnection();
            select = connection.prepareStatement(selectStmt);
            ArrayList<Records> rList = new ArrayList<Records>();
            result = select.executeQuery();
            while(result.next()) {
                Date date = result.getDate("date");
                int calorieIdle = result.getInt("calorieIdle");
                Date lastUpdate = result.getDate("lastUpdate");
                Records r = new Records(date.toLocalDate(), calorieIdle, lastUpdate.toLocalDate());
                rList.add(r);
            }
            return rList;

        } catch(SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (select != null) {
                select.close();
            }
            if (result != null) {
                result.close();
            }
        }
    }

    public Records getRecord(Date date) throws SQLException {
        String selectStmt = "SELECT * FROM Records WHERE date = ?;";
        Connection connection = null;
        PreparedStatement select = null;
        ResultSet result = null;

        try {
            connection = connectionManager.getConnection();
            select = connection.prepareStatement(selectStmt);
            select.setDate(1, date);
            result = select.executeQuery();
            if(result.next()) {
                Date resultDate = result.getDate("date");
                int calorieIdle = result.getInt("calorieIdle");
                Date lastUpdate = result.getDate("lastUpdate");
                Records r = new Records(resultDate.toLocalDate(), calorieIdle, lastUpdate.toLocalDate());
                return r;
            }
            return null;

        } catch(SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (select != null) {
                select.close();
            }
            if (result != null) {
                result.close();
            }
        }
    }

    public int delete(Records r) throws SQLException {
        String delete = "DELETE FROM Records WHERE Date = ?";
        Connection connection = null;
        PreparedStatement deleteStmt = null;
        try {
            SummaryDao sDao = new SummaryDao();
            sDao.delete(Date.valueOf(r.getDate()));
            SegmentTypesDao stDao = new SegmentTypesDao();
            stDao.delete(Date.valueOf(r.getDate()));
            connection = connectionManager.getConnection();
            deleteStmt = connection.prepareStatement(delete);
            deleteStmt.setDate(1, Date.valueOf(r.getDate()));
            int resultRows = deleteStmt.executeUpdate();
            return resultRows;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (deleteStmt != null) {
                deleteStmt.close();
            }
        }
    }
}