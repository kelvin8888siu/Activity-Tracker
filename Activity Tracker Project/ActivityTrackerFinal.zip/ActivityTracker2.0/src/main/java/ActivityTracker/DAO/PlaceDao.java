package ActivityTracker.DAO;

import ActivityTracker.model.Place;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class PlaceDao {
    protected ConnManager connectionManager;
    private static PlaceDao instance = null;
    public PlaceDao() {
        connectionManager = new ConnManager();
    }
    public static PlaceDao getInstance() {
        if(instance == null) {
            instance = new PlaceDao();
        }
        return instance;
    }

    public Place create(Place place) throws SQLException {
        String insertPlace = "INSERT INTO Place(SegmentID, PlaceID, Name, PlaceType) VALUES" +
                "(?,?,?,?);";
        Connection connection = null;
        PreparedStatement insertStmt = null;
        try {
            connection = connectionManager.getConnection();
            insertStmt = connection.prepareStatement(insertPlace);
            insertStmt.setInt(1, place.getSegmentId());
            insertStmt.setInt(2, place.getPlaceId());
            insertStmt.setString(3, place.getName());
            insertStmt.setString(4, place.getPlaceType());
            insertStmt.executeUpdate();
            return place;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (insertStmt != null) {
                insertStmt.close();
            }
        }
    }

    public ArrayList<Place> getAllPlaces() throws SQLException {
        String selectStmt = "SELECT * FROM Place;";
        Connection connection = null;
        PreparedStatement select = null;
        ResultSet result = null;
        try {
            connection = connectionManager.getConnection();
            select = connection.prepareStatement(selectStmt);
            result = select.executeQuery();
            ArrayList<Place> pList = new ArrayList<Place>();
            while (result.next()) {
                int placeTypeId = result.getInt("placeTypeId");
                int segmentId = result.getInt("segmentId");
                int placeId = result.getInt("placeId");
                String name = result.getString("name");
                String placeType = result.getString("placeType");
                Place p = new Place(placeTypeId, segmentId, name, placeType, placeId);
                pList.add(p);
            }
            return pList;
        } catch(SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (select != null) {
                select.close();
            }
            if (result != null) {
                result.close();
            }
        }
    }

    public ArrayList<Place> getAllPlacesBySegmentId(int s) throws SQLException {
        String selectStmt = "SELECT * FROM Place WHERE SegmentId = ?;";
        Connection connection = null;
        PreparedStatement select = null;
        ResultSet result = null;
        try {
            connection = connectionManager.getConnection();
            select = connection.prepareStatement(selectStmt);
            select.setInt(1, s);
            result = select.executeQuery();
            ArrayList<Place> pList = new ArrayList<Place>();
            while (result.next()) {
                int placeTypeId = result.getInt("placeTypeId");
                int segmentId = result.getInt("segmentId");
                int placeId = result.getInt("placeId");
                String name = result.getString("name");
                String placeType = result.getString("placeType");
                Place p = new Place(placeTypeId, segmentId, name, placeType, placeId);
                pList.add(p);
            }
            return pList;
        } catch(SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (select != null) {
                select.close();
            }
            if (result != null) {
                result.close();
            }
        }
    }

    public void delete(int s) throws SQLException {
        String delete = "DELETE FROM Place WHERE segmentId = ?;";
        Connection connection = null;
        PreparedStatement deleteStmt = null;
        try {
            PlaceDao pDao = new PlaceDao();
            ActivityPlacesDao apDao = new ActivityPlacesDao();
            ArrayList<Place> places = new ArrayList<Place>();
            places = pDao.getAllPlacesBySegmentId(s);
            for (Place p: places) {
                apDao.delete(p.getPlaceTypeId());
            }
            connection = connectionManager.getConnection();
            deleteStmt = connection.prepareStatement(delete);
            deleteStmt.setInt(1, s);
            deleteStmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (deleteStmt != null) {
                deleteStmt.close();
            }
        }
    }
}
