package ActivityTracker.DAO;

import ActivityTracker.model.SegmentTypes;

import javax.swing.text.Segment;
import java.sql.*;
import java.time.ZoneOffset;
import java.util.ArrayList;

public class SegmentTypesDao {
    protected ConnManager connectionManager;
    private static SegmentTypesDao instance = null;
    public SegmentTypesDao() {
        connectionManager = new ConnManager();
    }
    public static SegmentTypesDao getInstance() {
        if(instance == null) {
            instance = new SegmentTypesDao();
        }
        return instance;
    }

    public SegmentTypes create(SegmentTypes segmentType) throws SQLException {
        String insertSegmentType = "INSERT INTO SegmentTypes(Date, SegmentType, StartTime, EndTime, LastUpdate) " +
                "VALUES(?,?,?,?,?);";
        Connection connection = null;
        PreparedStatement insertStmt = null;
        try {
            connection = connectionManager.getConnection();
            insertStmt = connection.prepareStatement(insertSegmentType);
            insertStmt.setDate(1, Date.valueOf(segmentType.getDate()));
            insertStmt.setString(2, segmentType.getSegmentType());
            insertStmt.setTimestamp(3, Timestamp.valueOf(segmentType.getStartTime().toLocalDateTime()));
            insertStmt.setTimestamp(4, Timestamp.valueOf(segmentType.getEndTime().toLocalDateTime()));
            insertStmt.setDate(5, Date.valueOf(segmentType.getLastUpdate()));
            insertStmt.executeUpdate();
            return segmentType;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (insertStmt != null) {
                insertStmt.close();
            }
        }
    }

    public ArrayList<SegmentTypes> getAllSegmentTypes() throws SQLException {
        String selectStmt = "SELECT * FROM SegmentTypes;";
        Connection connection = null;
        PreparedStatement select = null;
        ResultSet result = null;
        try {
            connection = connectionManager.getConnection();
            select = connection.prepareStatement(selectStmt);
            result = select.executeQuery();
            ArrayList<SegmentTypes> stList = new ArrayList<SegmentTypes>();
            while(result.next()) {
                int segmentId = result.getInt("segmentId");
                Date date = result.getDate("date");
                String segmentType = result.getString("segmentType");
                Timestamp startTime = result.getTimestamp("startTime");
                Timestamp endTime = result.getTimestamp("endTime");
                Date lastUpdate = result.getDate("lastUpdate");
                SegmentTypes s = new SegmentTypes(segmentId, date.toLocalDate(), segmentType,
                        startTime.toLocalDateTime().atOffset(ZoneOffset.ofHours(-8)),
                        endTime.toLocalDateTime().atOffset(ZoneOffset.ofHours(-8)),
                        date.toLocalDate());
                stList.add(s);
            }
            return stList;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (select != null) {
                select.close();
            }
            if (result != null) {
                result.close();
            }
        }
    }

    public ArrayList<SegmentTypes> getAllSegmentTypesByDate(Date d) throws SQLException {
        String selectStmt = "SELECT * FROM SegmentTypes WHERE Date = ?;";
        Connection connection = null;
        PreparedStatement select = null;
        ResultSet result = null;
        try {
            connection = connectionManager.getConnection();
            select = connection.prepareStatement(selectStmt);
            select.setDate(1, d);
            result = select.executeQuery();
            ArrayList<SegmentTypes> stList = new ArrayList<SegmentTypes>();
            while(result.next()) {
                int segmentId = result.getInt("segmentId");
                Date date = result.getDate("date");
                String segmentType = result.getString("segmentType");
                Timestamp startTime = result.getTimestamp("startTime");
                Timestamp endTime = result.getTimestamp("endTime");
                Date lastUpdate = result.getDate("lastUpdate");
                SegmentTypes s = new SegmentTypes(segmentId, date.toLocalDate(), segmentType,
                        startTime.toLocalDateTime().atOffset(ZoneOffset.ofHours(-8)),
                        endTime.toLocalDateTime().atOffset(ZoneOffset.ofHours(-8)),
                        date.toLocalDate());
                stList.add(s);
            }
            return stList;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (select != null) {
                select.close();
            }
            if (result != null) {
                result.close();
            }
        }
    }


    public void delete(Date d) throws SQLException {
        String delete = "DELETE FROM SegmentTypes WHERE Date = ?;";
        Connection connection = null;
        PreparedStatement deleteStmt = null;
        try {
            SegmentTypesDao stDao = new SegmentTypesDao();
            ActivitySegmentTypesDao astDao = new ActivitySegmentTypesDao();
            PlaceDao pDao = new PlaceDao();
            ArrayList<SegmentTypes> segmentTypes = new ArrayList<SegmentTypes>();
            segmentTypes = stDao.getAllSegmentTypesByDate(d);
            for (SegmentTypes s: segmentTypes) {
                astDao.delete(s.getSegmentId());
                pDao.delete(s.getSegmentId());
            }
            connection = connectionManager.getConnection();
            deleteStmt = connection.prepareStatement(delete);
            deleteStmt.setDate(1, d);
            deleteStmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (deleteStmt != null) {
                deleteStmt.close();
            }
        }
    }
}
