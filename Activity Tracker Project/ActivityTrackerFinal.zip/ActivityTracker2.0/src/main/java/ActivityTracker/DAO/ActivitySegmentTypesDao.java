package ActivityTracker.DAO;

import ActivityTracker.model.ActivitySegmentTypes;
import ActivityTracker.model.ActivitySummary;

import java.sql.*;
import java.time.ZoneOffset;
import java.util.ArrayList;

public class ActivitySegmentTypesDao {
    protected ConnManager connectionManager;
    private static ActivitySegmentTypesDao instance = null;
    public ActivitySegmentTypesDao() {
        connectionManager = new ConnManager();
    }
    public static ActivitySegmentTypesDao getInstance() {
        if(instance == null) {
            instance = new ActivitySegmentTypesDao();
        }
        return instance;
    }

    public ActivitySegmentTypes create(ActivitySegmentTypes ast) throws SQLException {
        String insertAST = "INSERT INTO Activity_SegmentTypes(segmentId, startTime, endTime," +
                "activity, duration, distance, calories, steps) VALUES (?,?,?,?,?,?,?,?)";
        Connection connection = null;
        PreparedStatement insertStmt = null;
        try {
            connection = connectionManager.getConnection();
            insertStmt = connection.prepareStatement(insertAST);
            insertStmt.setInt(1, ast.getSegmentId());
            insertStmt.setTimestamp(2, Timestamp.valueOf(ast.getStartTime().toLocalDateTime()));
            insertStmt.setTimestamp(3, Timestamp.valueOf(ast.getEndTime().toLocalDateTime()));
            insertStmt.setString(4, ast.getActivity());
            insertStmt.setFloat(5, ast.getDuration());
            insertStmt.setFloat(6, ast.getDistance());
            insertStmt.setFloat(7, ast.getCalories());
            insertStmt.setInt(8, ast.getSteps());
            insertStmt.executeUpdate();
            return ast;
        } catch(SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (insertStmt != null) {
                insertStmt.close();
            }
        }
    }

    public ArrayList<ActivitySegmentTypes> getAllActivitySegmentTypes() throws SQLException {
        String selectStmt = "SELECT * FROM Activity_SegmentTypes;";
        Connection connection = null;
        PreparedStatement select = null;
        ResultSet result = null;
        try {
            connection = connectionManager.getConnection();
            select = connection.prepareStatement(selectStmt);
            result = select.executeQuery();
            ArrayList<ActivitySegmentTypes> asList = new ArrayList<ActivitySegmentTypes>();
            while (result.next()) {
                int activitySegmentTypeId = result.getInt("activity_SegmentTypesId");
                int segmentId = result.getInt("segmentId");
                Timestamp startTime = result.getTimestamp("startTime");
                Timestamp endTime = result.getTimestamp("endTime");
                String activity = result.getString("activity");
                float duration = result.getFloat("duration");
                float distance = result.getFloat("distance");
                float calories = result.getFloat("calories");
                int steps = result.getInt("steps");
                ActivitySegmentTypes as = new ActivitySegmentTypes(activitySegmentTypeId, segmentId,
                        startTime.toLocalDateTime().atOffset(ZoneOffset.ofHours(-8)),
                        endTime.toLocalDateTime().atOffset(ZoneOffset.ofHours(-8)),
                        activity, duration, distance, calories, steps);
                asList.add(as);

            }
            return asList;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (select != null) {
                select.close();
            }
            if (result != null) {
                result.close();
            }
        }
    }

    public void delete(int s) throws SQLException {
        String delete = "DELETE FROM Activity_SegmentTypes WHERE SegmentId = ?;";
        Connection connection = null;
        PreparedStatement deleteStmt = null;
        try {
            connection = connectionManager.getConnection();
            deleteStmt = connection.prepareStatement(delete);
            deleteStmt.setInt(1, s);
            deleteStmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (deleteStmt != null) {
                deleteStmt.close();
            }
        }
    }
}
