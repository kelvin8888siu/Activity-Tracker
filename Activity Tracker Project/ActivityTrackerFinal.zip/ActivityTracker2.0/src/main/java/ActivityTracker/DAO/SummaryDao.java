package ActivityTracker.DAO;

import ActivityTracker.model.Summary;

import java.sql.*;
import java.util.ArrayList;

public class SummaryDao {
    protected ConnManager connectionManager;
    private static SummaryDao instance = null;
    public SummaryDao() {
        connectionManager = new ConnManager();
    }
    public static SummaryDao getInstance() {
        if(instance == null) {
            instance = new SummaryDao();
        }
        return instance;
    }

    public Summary create(Summary summary) throws SQLException {
        String insertSummary = "INSERT INTO Summary(Date) VALUES (?);";
        Connection connection = null;
        PreparedStatement insertStmt = null;
        try {
            connection = connectionManager.getConnection();
            insertStmt = connection.prepareStatement(insertSummary);
            insertStmt.setDate(1, Date.valueOf(summary.getDate()));
            insertStmt.executeUpdate();
            return summary;

        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (insertStmt != null) {
                insertStmt.close();
            }
        }
    }

    public ArrayList<Summary> getAllSummary() throws SQLException {
        String selectStmt = "SELECT * FROM Summary;";
        Connection connection = null;
        PreparedStatement select = null;
        ResultSet result = null;

        try {
            connection = connectionManager.getConnection();
            select = connection.prepareStatement(selectStmt);
            result = select.executeQuery();
            ArrayList<Summary> sList = new ArrayList<Summary>();

            while (result.next()) {
                Date date = result.getDate("date");
                int summaryId = result.getInt("summaryId");
                Summary s = new Summary(summaryId, date.toLocalDate());
                sList.add(s);
            }
            return sList;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (select != null) {
                select.close();
            }
            if (result != null) {
                result.close();
            }
        }
    }

    public ArrayList<Summary> getAllSummaryByDate(Date d) throws SQLException {
        String selectStmt = "SELECT * FROM Summary WHERE Date = ?;";
        Connection connection = null;
        PreparedStatement select = null;
        ResultSet result = null;

        try {
            connection = connectionManager.getConnection();
            select = connection.prepareStatement(selectStmt);
            select.setDate(1, d);
            result = select.executeQuery();
            ArrayList<Summary> sList = new ArrayList<Summary>();

            while (result.next()) {
                Date date = result.getDate("date");
                int summaryId = result.getInt("summaryId");
                Summary s = new Summary(summaryId, date.toLocalDate());
                sList.add(s);
            }
            return sList;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (select != null) {
                select.close();
            }
            if (result != null) {
                result.close();
            }
        }
    }

    public void delete(Date d) throws SQLException {
        String delete = "DELETE FROM Summary WHERE Date = ?;";
        Connection connection = null;
        PreparedStatement deleteStmt = null;
        try {
            SummaryDao sDao = new SummaryDao();
            ActivitySummaryDao asDao = new ActivitySummaryDao();
            ArrayList<Summary> summary = new ArrayList<Summary>();
            summary = sDao.getAllSummaryByDate(d);

            for (Summary s: summary) {
                asDao.delete(s.getSummaryId());
            }
            connection = connectionManager.getConnection();
            deleteStmt = connection.prepareStatement(delete);
            deleteStmt.setDate(1, d);
            deleteStmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (deleteStmt != null) {
                deleteStmt.close();
            }
        }
    }
}
