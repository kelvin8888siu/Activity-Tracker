package ActivityTracker.DAO;

import ActivityTracker.model.ActivityPlaces;
import ActivityTracker.model.ActivitySegmentTypes;

import java.sql.*;
import java.time.ZoneOffset;
import java.util.ArrayList;

public class ActivityPlacesDao {
    protected ConnManager connectionManager;
    private static ActivityPlacesDao instance = null;
    public ActivityPlacesDao() {
        connectionManager = new ConnManager();
    }
    public static ActivityPlacesDao getInstance() {
        if(instance == null) {
            instance = new ActivityPlacesDao();
        }
        return instance;
    }

    public ActivityPlaces create(ActivityPlaces ap) throws SQLException {
        String insertAP = "INSERT INTO Activity_Places(placetypeId, startTime, endTime," +
                "activity, duration, distance, calories, steps) VALUES (?,?,?,?,?,?,?,?)";
        Connection connection = null;
        PreparedStatement insertStmt = null;
        try {
            connection = connectionManager.getConnection();
            insertStmt = connection.prepareStatement(insertAP);
            insertStmt.setInt(1, ap.getPlaceTypeId());
            insertStmt.setTimestamp(2, Timestamp.valueOf(ap.getStartTime().toLocalDateTime()));
            insertStmt.setTimestamp(3, Timestamp.valueOf(ap.getEndTime().toLocalDateTime()));
            insertStmt.setString(4, ap.getActivity());
            insertStmt.setFloat(5, ap.getDuration());
            insertStmt.setFloat(6, ap.getDistance());
            insertStmt.setFloat(7, ap.getCalories());
            insertStmt.setInt(8, ap.getSteps());
            insertStmt.executeUpdate();
            return ap;
        } catch(SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (insertStmt != null) {
                insertStmt.close();
            }
        }
    }

    public ArrayList<ActivityPlaces> getAllActivityPlaces() throws SQLException{
        String selectStmt = "SELECT * FROM Activity_Places;";
        Connection connection = null;
        PreparedStatement select = null;
        ResultSet result = null;
        try {
            connection = connectionManager.getConnection();
            select = connection.prepareStatement(selectStmt);
            result = select.executeQuery();
            ArrayList<ActivityPlaces> asList = new ArrayList<ActivityPlaces>();
            while (result.next()) {
                int activityPlacesId = result.getInt("activity_placesId");
                int placetypeId = result.getInt("placetypeId");
                Timestamp startTime = result.getTimestamp("startTime");
                Timestamp endTime = result.getTimestamp("endTime");
                String activity = result.getString("activity");
                float duration = result.getFloat("duration");
                float distance = result.getFloat("distance");
                float calories = result.getFloat("calories");
                int steps = result.getInt("steps");
                ActivityPlaces as = new ActivityPlaces(activityPlacesId, placetypeId,
                        startTime.toLocalDateTime().atOffset(ZoneOffset.ofHours(-8)),
                        endTime.toLocalDateTime().atOffset(ZoneOffset.ofHours(-8)),
                        activity, duration, distance, calories, steps);
                asList.add(as);

            }
            return asList;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (select != null) {
                select.close();
            }
            if (result != null) {
                result.close();
            }
        }
    }

    public void delete(int s) throws SQLException {
        String delete = "DELETE FROM Activity_Places WHERE placeTypeId = ?;";
        Connection connection = null;
        PreparedStatement deleteStmt = null;
        try {
            connection = connectionManager.getConnection();
            deleteStmt = connection.prepareStatement(delete);
            deleteStmt.setInt(1, s);
            deleteStmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (deleteStmt != null) {
                deleteStmt.close();
            }
        }
    }
}
