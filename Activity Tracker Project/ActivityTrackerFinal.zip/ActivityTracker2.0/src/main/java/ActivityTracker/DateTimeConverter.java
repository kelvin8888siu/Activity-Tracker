package ActivityTracker;

import java.sql.Date;
import java.sql.Timestamp;

public class DateTimeConverter {
    private String year;
    private String month;
    private String day;
    private String hour;
    private String min;
    private String sec;
    private String z1;
    private String z2;

    public DateTimeConverter(Object value, String type) throws IllegalArgumentException {
        String date = String.valueOf(value);

        if (type != "date" && type != "timestamp" && type != "lastUpdate") {
            throw new IllegalArgumentException("Invalid Argument type");
        }

        if (value == null) {
            year = "1970";
            month = "01";
            day = "01";
            hour = "01";
            min = "01";
            sec = "01";
            z1 = "-01";
            z2 = "01";
        } else {
            if (type == "date" || type == "timestamp") {
                year = date.substring(0, 4);
                month = date.substring(4, 6);
                day = date.substring(6, 8);
            }
            if (type == "timestamp") {
                hour = date.substring(9, 11);
                min = date.substring(11, 13);
                sec = date.substring(13, 15);
                z1 = date.substring(15, 18);
                z2 = date.substring(18, 20);
            }
        }
    }

    public String DateConvert() {
        String dateFormat = String.format("%s-%s-%s", year, month, day);
        return dateFormat;
    }

    public String DateTimeConvert() {
        String dateTimeFormat = String.format("%s-%s-%sT%s:%s:%s%s:%s", year, month, day, hour, min, sec, z1, z2);
        return dateTimeFormat;
    }
}
