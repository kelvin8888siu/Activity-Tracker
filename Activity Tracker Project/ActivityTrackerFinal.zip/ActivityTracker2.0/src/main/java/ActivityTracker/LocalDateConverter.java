package ActivityTracker;

import java.time.LocalDate;

import java.time.format.DateTimeFormatter;
import org.springframework.boot.context.properties.ConfigurationPropertiesBinding;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;


@Component
@ConfigurationPropertiesBinding
public class LocalDateConverter implements Converter<String, LocalDate> {

    @Override
    public LocalDate convert(String source) {
        try {
            if (source == null) {
                return null;
            }

            if (source.contains(":") == false) {

                LocalDate ld = LocalDate.parse(source, DateTimeFormatter.ofPattern("yyyy-MM-dd"));



                return ld;
            } else {
                return LocalDate.parse(source);
            }

        } catch (Exception ex) {
            //ex.printStackTrace();
        }

        return null;
    }

}
