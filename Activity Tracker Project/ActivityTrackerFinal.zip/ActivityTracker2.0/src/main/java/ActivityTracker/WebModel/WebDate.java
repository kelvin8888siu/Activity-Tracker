package ActivityTracker.WebModel;
import java.sql.Date;

public class WebDate {
    private Date date;

    public WebDate(){}

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
