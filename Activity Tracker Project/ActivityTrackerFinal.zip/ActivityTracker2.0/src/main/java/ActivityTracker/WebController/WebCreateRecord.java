package ActivityTracker.WebController;



import ActivityTracker.DAO.RecordsDao;
import ActivityTracker.model.Records;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;


import java.sql.SQLException;

@Controller
public class WebCreateRecord {

    @GetMapping("web/createRecord")
    public String createRecordForm(Model model) {
        model.addAttribute("record", new Records());
        return "createRecord";
    }

    @PostMapping("web/createRecord")
    public String recordSubmit(@ModelAttribute Records record, Model model) throws SQLException {
        RecordsDao rDao = new RecordsDao();

        rDao.create(record);
        model.addAttribute("record", record);
        return "Recordresult";

    }
}
