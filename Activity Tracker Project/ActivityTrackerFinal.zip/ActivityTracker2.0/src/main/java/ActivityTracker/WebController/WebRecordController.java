package ActivityTracker.WebController;

import ActivityTracker.DAO.RecordsDao;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.sql.SQLException;

@Controller
public class WebRecordController {

    @GetMapping("web/records")
    public String getAllRec(Model model) {
        RecordsDao test = new RecordsDao();
        try {
            model.addAttribute("records", test.getAllRecords());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return "records";
    }
}
