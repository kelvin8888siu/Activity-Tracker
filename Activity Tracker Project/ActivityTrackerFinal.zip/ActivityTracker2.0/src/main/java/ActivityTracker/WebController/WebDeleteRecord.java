package ActivityTracker.WebController;

import ActivityTracker.DAO.RecordsDao;
import ActivityTracker.WebModel.WebDate;
import ActivityTracker.model.Records;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.sql.SQLException;

@Controller
public class WebDeleteRecord {

    @GetMapping("web/deleteRecord")
    public String deleteRecordForm(Model model) {

        model.addAttribute("date", new WebDate());
        return "deleteRecord";
    }

    @PostMapping("web/deleteRecord")
    public String deleteRecord(@ModelAttribute WebDate date, Model model) throws SQLException {
        RecordsDao rDao = new RecordsDao();
        System.out.println(date.getDate());
        Records r = rDao.getRecord(date.getDate());

        rDao.delete(r);
        model.addAttribute("date", date);
        return "deleteRecordResult";
    }
}
