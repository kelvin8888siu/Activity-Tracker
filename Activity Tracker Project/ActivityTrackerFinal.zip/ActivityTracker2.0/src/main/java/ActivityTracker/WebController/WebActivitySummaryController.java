package ActivityTracker.WebController;

import ActivityTracker.DAO.ActivitySummaryDao;
import ActivityTracker.DAO.RecordsDao;
import org.springframework.data.jdbc.core.JdbcAggregateTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.sql.SQLException;

@Controller
public class WebActivitySummaryController {

    @GetMapping("web/activitySummary")
    public String getAllActivitySummary(Model model) {
        ActivitySummaryDao test = new ActivitySummaryDao();
        try {
            model.addAttribute("activitySummary", test.getAllActivitySummary());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return "activitySummary";
    }

}
