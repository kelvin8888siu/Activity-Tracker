package ActivityTracker.WebController;



import ActivityTracker.DAO.RecordsDao;
import ActivityTracker.DAO.SummaryDao;
import ActivityTracker.model.Records;
import ActivityTracker.model.Summary;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;


import java.sql.SQLException;

@Controller
public class WebCreateSummary {

    @GetMapping("web/createSummary")
    public String createRecordForm(Model model) {
        model.addAttribute("summary", new Summary());
        return "createSummary";
    }

    @PostMapping("web/createSummary")
    public String recordSubmit(@ModelAttribute Summary s, Model model) throws SQLException {
        SummaryDao sDao = new SummaryDao();

        sDao.create(s);
        model.addAttribute("summary", s);
        return "createSummaryResult";

    }
}