package ActivityTracker.WebController;



import ActivityTracker.DAO.ActivitySummaryDao;
import ActivityTracker.DAO.RecordsDao;
import ActivityTracker.DAO.SummaryDao;
import ActivityTracker.model.ActivitySummary;
import ActivityTracker.model.Records;
import ActivityTracker.model.Summary;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;


import java.sql.SQLException;

@Controller
public class WebCreateActivitySummaryController {

    @GetMapping("web/createActivitySummary")
    public String createActivitySummaryForm(Model model) {
        model.addAttribute("activitySummary", new ActivitySummary());
        return "createActivitySummary";
    }

    @PostMapping("web/createActivitySummary")
    public String ActivitySummarySubmit(@ModelAttribute ActivitySummary s, Model model) throws SQLException {
        ActivitySummaryDao sDao = new ActivitySummaryDao();

        sDao.create(s);
        model.addAttribute("activitySummary", s);
        return "createActivitySummaryResult";

    }
}