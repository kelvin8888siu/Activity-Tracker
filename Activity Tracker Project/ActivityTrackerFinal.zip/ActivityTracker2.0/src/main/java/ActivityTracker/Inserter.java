package ActivityTracker;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import ActivityTracker.DAO.*;
import ActivityTracker.model.Records;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import ActivityTracker.model.*;

import javax.swing.text.Segment;

public class Inserter {

    public static JSONArray fileOpen() throws IOException, ParseException {
        try {
            JSONParser parser = new JSONParser();
            JSONArray file = (JSONArray) parser.parse(new FileReader("/Users/Saurav595/Downloads/storyline.json"));
            return file;
        }
        catch (IOException e){
            e.printStackTrace();
        }
        catch (ParseException e){
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Function used for loading data into the Records table.
     */
    public static void recordsBulkLoad() {
        try {
            JSONArray file = fileOpen();
            Records record = new Records();
            RecordsDao rDAO = RecordsDao.getInstance();

            for (Object o : file){
                JSONObject objects = (JSONObject) o;

                DateTimeConverter dtc = new DateTimeConverter(objects.get("date"), "date");
                LocalDate localDate = LocalDate.parse(dtc.DateConvert());
                record.setDate(localDate);

                record.setCalorieIdle(Integer.valueOf(String.valueOf(objects.get("caloriesIdle"))));

                DateTimeConverter dtc2 = new DateTimeConverter(objects.get("lastUpdate"), "date");
                LocalDate lastUp = LocalDate.parse(dtc2.DateConvert());
                record.setLastupdated(lastUp);
                try {
                    rDAO.create(record);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    public static void summaryBulkLoad() {
        try {
            JSONArray file = fileOpen();
            Summary summary = new Summary();
            SummaryDao sDAO = SummaryDao.getInstance();

            for (Object o : file){
                JSONObject objects = (JSONObject) o;

                DateTimeConverter dtc = new DateTimeConverter(objects.get("date"), "date");
                LocalDate localDate = LocalDate.parse(dtc.DateConvert());
                summary.setDate(localDate);

                try {
                    sDAO.create(summary);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    public static void segmentTypesBulkLoad() {
        try {
            JSONArray file = fileOpen();
            SegmentTypes segmentTypes = new SegmentTypes();
            SegmentTypesDao segDAO = SegmentTypesDao.getInstance();

            for (Object o : file){
                JSONObject objects = (JSONObject) o;

                DateTimeConverter dtc = new DateTimeConverter(objects.get("date"), "date");
                LocalDate localDate = LocalDate.parse(dtc.DateConvert());
                segmentTypes.setDate(localDate);

                JSONArray seg = (JSONArray) objects.get("segments");
                for (Object o1 : seg) {

                    JSONObject objects1 = (JSONObject) o1;

                    segmentTypes.setSegmentType(String.valueOf(objects1.get("type")));

                    DateTimeConverter dtc2 = new DateTimeConverter(objects1.get("startTime"), "timestamp");
                    OffsetDateTime startTime = OffsetDateTime.parse(dtc2.DateTimeConvert(), DateTimeFormatter.ISO_OFFSET_DATE_TIME);
                    segmentTypes.setStartTime(startTime);

                    DateTimeConverter dtc3 = new DateTimeConverter(objects1.get("endTime"), "timestamp");
                    OffsetDateTime endTime = OffsetDateTime.parse(dtc3.DateTimeConvert(), DateTimeFormatter.ISO_OFFSET_DATE_TIME);
                    segmentTypes.setEndTime(endTime);

                    DateTimeConverter dtc4 = new DateTimeConverter(objects1.get("lastUpdate"), "date");
                    LocalDate lastUp = LocalDate.parse(dtc4.DateConvert());
                    segmentTypes.setLastUpdate(lastUp);

                    try {
                        segDAO.create(segmentTypes);
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    public static void activitySummaryBulkLoad() {
        try {
            JSONArray file = fileOpen();
            ActivitySummary actSummary = new ActivitySummary();
            ActivitySummaryDao actSDAO = ActivitySummaryDao.getInstance();
            int summaryID = 1;

            for (Object o : file){
                JSONObject objects = (JSONObject) o;

                if (objects.get("summary") == null){
                    summaryID += 1;
                    continue;
                }
                else {
                    JSONArray summaryS = (JSONArray) objects.get("summary");

                    for (Object o1 : summaryS) {

                        JSONObject objects1 = (JSONObject) o1;
                        String activity = String.valueOf(objects1.get("activity"));

                        if (activity.equals("walking") || activity.equals("running") || activity.equals("cycling")) {

                            actSummary.setSummaryId(summaryID);
                            actSummary.setActivity(activity);
                            actSummary.setDuration(Float.valueOf(String.valueOf(objects1.get("duration"))));
                            actSummary.setDistance(Float.valueOf(String.valueOf(objects1.get("distance"))));
                            actSummary.setCalories(Float.valueOf(String.valueOf(objects1.get("calories"))));

                            if (objects1.get("steps") == null) {
                                actSummary.setSteps(0);
                            } else {
                                actSummary.setSteps(Integer.valueOf(String.valueOf(objects1.get("steps"))));
                            }

                            try {
                                actSDAO.create(actSummary);
                            } catch (SQLException throwables) {
                                throwables.printStackTrace();
                            }
                        }
                        else if (activity.equals("transport")) {

                            actSummary.setSummaryId(summaryID);
                            actSummary.setActivity(activity);
                            actSummary.setDuration(Float.valueOf(String.valueOf(objects1.get("duration"))));
                            actSummary.setDistance(Float.valueOf(String.valueOf(objects1.get("distance"))));
                            actSummary.setCalories(0.0F);
                            actSummary.setSteps(0);

                            try {
                                actSDAO.create(actSummary);
                            } catch (SQLException throwables) {
                                throwables.printStackTrace();
                            }
                        }
                    }
                    summaryID += 1;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    public static void placeBulkLoad() {
        try {
            JSONArray file = fileOpen();

            Place place = new Place();
            PlaceDao placeDao = PlaceDao.getInstance();

            int segId = 1;

            for (Object o : file) {
                JSONObject objects = (JSONObject) o;
                JSONArray seg = (JSONArray) objects.get("segments");

                for (Object o1 : seg) {
                    JSONObject objects1 = (JSONObject) o1;
                    String SegmentType = String.valueOf((objects1.get("type")));

                    if (SegmentType.equals("place")) {

                        JSONObject objectsPlace = (JSONObject) objects1.get("place");

                        //place
                        place.setSegmentId(segId);
                        place.setPlaceId(Integer.valueOf(String.valueOf(objectsPlace.get("id"))));
                        place.setName(String.valueOf(objectsPlace.get("name")));
                        place.setPlaceType(String.valueOf(objectsPlace.get("type")));

                        try {
                            placeDao.create(place);
                        } catch (SQLException throwables) {
                            throwables.printStackTrace();
                        }
                    }
                }
                segId += 1;
            }
        }
        catch(IOException e){
            e.printStackTrace();
        } catch(ParseException e){
            e.printStackTrace();
        }
    }

    public static void activitySegmentTypesBulkLoad() {
        try {
            JSONArray file = fileOpen();
            ActivitySegmentTypes ast = new ActivitySegmentTypes();
            ActivitySegmentTypesDao astDao = ActivitySegmentTypesDao.getInstance();

            int segId = 1;

            for (Object o : file) {
                JSONObject objects = (JSONObject) o;
                JSONArray seg = (JSONArray) objects.get("segments");

                for (Object o1 : seg) {

                    JSONObject objects1 = (JSONObject) o1;
                    String type = String.valueOf(objects1.get("type"));

                    if (((type.equals("move")) && ((objects1.get("activities")) != null)) ||
                            ((type.equals("off")) && ((objects1.get("activities")) != null))) {

                        JSONArray act = (JSONArray) objects1.get("activities");

                        for (Object o2 : act) {
                            JSONObject objects2 = (JSONObject) o2;

                            ast.setSegmentId(segId);
                            ast.setActivity(String.valueOf(objects2.get("activity")));

                            DateTimeConverter dtc3 = new DateTimeConverter(objects2.get("startTime"), "timestamp");
                            OffsetDateTime startTime3 = OffsetDateTime.parse(dtc3.DateTimeConvert(), DateTimeFormatter.ISO_OFFSET_DATE_TIME);
                            ast.setStartTime(startTime3);

                            DateTimeConverter dtc4 = new DateTimeConverter(objects2.get("endTime"), "timestamp");
                            OffsetDateTime endTime4 = OffsetDateTime.parse(dtc4.DateTimeConvert(), DateTimeFormatter.ISO_OFFSET_DATE_TIME);
                            ast.setEndTime(endTime4);

                            if (objects2.get("duration") == null) {
                                ast.setDuration(0.0F);
                            } else {
                                ast.setDuration(Float.valueOf(String.valueOf(objects2.get("duration"))));
                            }

                            if (objects2.get("distance") == null) {
                                ast.setDistance(0.0F);
                            } else {
                                ast.setDistance(Float.valueOf(String.valueOf(objects2.get("distance"))));
                            }

                            if (((objects2.get("calories")) != null) && (((objects2.get("steps")) != null))) {
                                ast.setSteps(Integer.valueOf(String.valueOf(objects2.get("steps"))));
                                ast.setCalories(Float.valueOf(String.valueOf(objects2.get("calories"))));

                            } else if (((objects2.get("calories")) == null) && (((objects2.get("steps")) != null))) {
                                ast.setSteps(Integer.valueOf(String.valueOf(objects2.get("steps"))));
                                ast.setCalories(0.0F);

                            } else if (((objects2.get("calories")) != null) && (((objects2.get("steps")) == null))) {
                                ast.setSteps(0);
                                ast.setCalories(Float.valueOf(String.valueOf(objects2.get("calories"))));

                            } else if (((objects2.get("calories")) == null) && (((objects2.get("steps")) == null))) {
                                ast.setSteps(0);
                                ast.setCalories(0.0F);
                            }

                            try {
                                astDao.create(ast);
                            } catch (SQLException throwables) {
                                throwables.printStackTrace();
                            }
                        }
                    }
                    segId += 1;
                }
            }
        } catch(IOException e){
            e.printStackTrace();
        } catch(ParseException e){
            e.printStackTrace();
        }
    }

    public static void activityPlaceBulkLoad() {
        try {
            JSONArray file = fileOpen();

            ActivityPlaces ap = new ActivityPlaces();
            ActivityPlacesDao apDao = ActivityPlacesDao.getInstance();

            int placeTypeId = 1;

            for (Object o : file) {
                JSONObject objects = (JSONObject) o;
                JSONArray seg = (JSONArray) objects.get("segments");

                for (Object o1 : seg) {
                    JSONObject objects1 = (JSONObject) o1;
                    String type = String.valueOf((objects1.get("type")));

                    if ((type.equals("place")) && ((objects1.get("activities")) != null)) {

                        JSONArray act = (JSONArray) objects1.get("activities");

                        ap.setPlaceTypeId(placeTypeId);

                        for (Object o2 : act) {
                            JSONObject objects2 = (JSONObject) o2;

                            ap.setActivity(String.valueOf(objects2.get("activity")));

                            DateTimeConverter dtc3 = new DateTimeConverter(objects2.get("startTime"), "timestamp");
                            OffsetDateTime startTime3 = OffsetDateTime.parse(dtc3.DateTimeConvert(), DateTimeFormatter.ISO_OFFSET_DATE_TIME);
                            ap.setStartTime(startTime3);

                            DateTimeConverter dtc4 = new DateTimeConverter(objects2.get("endTime"), "timestamp");
                            OffsetDateTime endTime4 = OffsetDateTime.parse(dtc4.DateTimeConvert(), DateTimeFormatter.ISO_OFFSET_DATE_TIME);
                            ap.setEndTime(endTime4);

                            if (objects2.get("duration") == null) {
                                ap.setDuration(0.0F);
                            } else {
                                ap.setDuration(Float.valueOf(String.valueOf(objects2.get("duration"))));
                            }

                            if (objects2.get("distance") == null) {
                                ap.setDistance(0.0F);
                            } else {
                                ap.setDistance(Float.valueOf(String.valueOf(objects2.get("distance"))));
                            }

                            if (((objects2.get("calories")) != null) && (((objects2.get("steps")) != null))) {
                                ap.setSteps(Integer.valueOf(String.valueOf(objects2.get("steps"))));
                                ap.setCalories(Float.valueOf(String.valueOf(objects2.get("calories"))));

                            } else if (((objects2.get("calories")) == null) && (((objects2.get("steps")) != null))) {
                                ap.setSteps(Integer.valueOf(String.valueOf(objects2.get("steps"))));
                                ap.setCalories(0.0F);

                            } else if (((objects2.get("calories")) != null) && (((objects2.get("steps")) == null))) {
                                ap.setSteps(0);
                                ap.setCalories(Float.valueOf(String.valueOf(objects2.get("calories"))));

                            } else if (((objects2.get("calories")) == null) && (((objects2.get("steps")) == null))) {
                                ap.setSteps(0);
                                ap.setCalories(0.0F);
                            }
                        }
                        try {
                            apDao.create(ap);
                        } catch (SQLException throwables) {
                            throwables.printStackTrace();
                        }
                        placeTypeId += 1;
                    }
                }
            }
        } catch(IOException e){
            e.printStackTrace();
        } catch(ParseException e){
            e.printStackTrace();
        }
    }

    /**
     * Main function used to load JSON file data into MySQL database.
     */
    public static void main(String[] args) {
        recordsBulkLoad();
        summaryBulkLoad();
        segmentTypesBulkLoad();
        activitySummaryBulkLoad();
        placeBulkLoad();
        activitySegmentTypesBulkLoad();
        activityPlaceBulkLoad();
    }
}
