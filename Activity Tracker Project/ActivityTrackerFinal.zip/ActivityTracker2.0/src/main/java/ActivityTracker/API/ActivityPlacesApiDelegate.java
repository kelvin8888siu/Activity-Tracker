package ActivityTracker.API;

import ActivityTracker.model.ActivityPlaces;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.NativeWebRequest;

import java.util.List;
import java.util.Optional;

/**
 * A delegate to be called by the {@link ActivityPlacesApiController}}.
 * Implement this interface with a {@link org.springframework.stereotype.Service} annotated class.
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2021-08-05T15:58:24.603184-04:00[America/Toronto]")

public interface ActivityPlacesApiDelegate {

    default Optional<NativeWebRequest> getRequest() {
        return Optional.empty();
    }

    /**
     * POST /activityPlaces : creates an activity place
     *
     * @param activityPlaces  (required)
     * @return Successfully created. (status code 200)
     *         or Did not work. (status code 400)
     * @see ActivityPlacesApi#createActivityPlace
     */
    default ResponseEntity<Void> createActivityPlace(ActivityPlaces activityPlaces) {
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

    }

    /**
     * GET /activityPlaces : obtains all activity places
     * gets all activity places
     *
     * @return Returned all activity places (status code 200)
     *         or Did not work. (status code 400)
     * @see ActivityPlacesApi#getAllActivityPlaces
     */
    default ResponseEntity<List<ActivityPlaces>> getAllActivityPlaces() {
        getRequest().ifPresent(request -> {
            for (MediaType mediaType: MediaType.parseMediaTypes(request.getHeader("Accept"))) {
                if (mediaType.isCompatibleWith(MediaType.valueOf("application/json"))) {
                    String exampleString = "{ \"duration\" : 1.4658129, \"activityPlaceId\" : 0, \"activity\" : \"activity\", \"distance\" : 5.962134, \"placeTypeId\" : 6, \"startTime\" : \"2000-01-23T04:56:07.000+00:00\", \"endTime\" : \"2000-01-23T04:56:07.000+00:00\", \"calories\" : 5.637377, \"steps\" : 2 }";
                    ApiUtil.setExampleResponse(request, "application/json", exampleString);
                    break;
                }
            }
        });
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

    }

}
