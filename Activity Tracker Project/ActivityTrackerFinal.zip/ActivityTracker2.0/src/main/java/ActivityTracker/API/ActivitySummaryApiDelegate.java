package ActivityTracker.API;

import ActivityTracker.model.ActivitySummary;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.NativeWebRequest;

import java.util.List;
import java.util.Optional;

/**
 * A delegate to be called by the {@link ActivitySummaryApiController}}.
 * Implement this interface with a {@link org.springframework.stereotype.Service} annotated class.
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2021-08-05T15:58:24.603184-04:00[America/Toronto]")

public interface ActivitySummaryApiDelegate {

    default Optional<NativeWebRequest> getRequest() {
        return Optional.empty();
    }

    /**
     * POST /activitySummary : creates an activity summary
     *
     * @param activitySummary  (required)
     * @return Successfully created. (status code 200)
     *         or Did not work. (status code 400)
     * @see ActivitySummaryApi#createActivitySummary
     */
    default ResponseEntity<Void> createActivitySummary(ActivitySummary activitySummary) {
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

    }

    /**
     * GET /activitySummary/{date} : Find activity summary by date
     * Returns an activity summary by date
     *
     * @param date date of activity (required)
     * @return successful operation (status code 200)
     *         or Invalid date or activity supplied (status code 400)
     * @see ActivitySummaryApi#getAllActivitiesByDate
     */
    default ResponseEntity<List<ActivitySummary>> getAllActivitiesByDate(String date) {
        getRequest().ifPresent(request -> {
            for (MediaType mediaType: MediaType.parseMediaTypes(request.getHeader("Accept"))) {
                if (mediaType.isCompatibleWith(MediaType.valueOf("application/json"))) {
                    String exampleString = "{ \"duration\" : 1.4658129, \"activitySummaryId\" : 0, \"activity\" : \"activity\", \"distance\" : 5.962134, \"summaryId\" : 6, \"startTime\" : \"2000-01-23T04:56:07.000+00:00\", \"endTime\" : \"2000-01-23T04:56:07.000+00:00\", \"calories\" : 5.637377, \"steps\" : 2 }";
                    ApiUtil.setExampleResponse(request, "application/json", exampleString);
                    break;
                }
            }
        });
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

    }

    /**
     * GET /activitySummary : obtains all activity summary
     * gets all the activity summary
     *
     * @return Returned all activity summary. (status code 200)
     *         or Did not work. (status code 400)
     * @see ActivitySummaryApi#getAllActivitySummary
     */
    default ResponseEntity<List<ActivitySummary>> getAllActivitySummary() {
        getRequest().ifPresent(request -> {
            for (MediaType mediaType: MediaType.parseMediaTypes(request.getHeader("Accept"))) {
                if (mediaType.isCompatibleWith(MediaType.valueOf("application/json"))) {
                    String exampleString = "{ \"duration\" : 1.4658129, \"activitySummaryId\" : 0, \"activity\" : \"activity\", \"distance\" : 5.962134, \"summaryId\" : 6, \"startTime\" : \"2000-01-23T04:56:07.000+00:00\", \"endTime\" : \"2000-01-23T04:56:07.000+00:00\", \"calories\" : 5.637377, \"steps\" : 2 }";
                    ApiUtil.setExampleResponse(request, "application/json", exampleString);
                    break;
                }
            }
        });
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

    }

    /**
     * GET /activitySummary/{date}/{activity} : Find specific activity summary by date
     * Returns a specific activity summary by date
     *
     * @param date date of activity (required)
     * @param activity type of activity (required)
     * @return successful operation (status code 200)
     *         or Invalid date or activity supplied (status code 400)
     * @see ActivitySummaryApi#getSpecificActivitySummaryByDate
     */
    default ResponseEntity<List<ActivitySummary>> getSpecificActivitySummaryByDate(String date,
        String activity) {
        getRequest().ifPresent(request -> {
            for (MediaType mediaType: MediaType.parseMediaTypes(request.getHeader("Accept"))) {
                if (mediaType.isCompatibleWith(MediaType.valueOf("application/json"))) {
                    String exampleString = "{ \"duration\" : 1.4658129, \"activitySummaryId\" : 0, \"activity\" : \"activity\", \"distance\" : 5.962134, \"summaryId\" : 6, \"startTime\" : \"2000-01-23T04:56:07.000+00:00\", \"endTime\" : \"2000-01-23T04:56:07.000+00:00\", \"calories\" : 5.637377, \"steps\" : 2 }";
                    ApiUtil.setExampleResponse(request, "application/json", exampleString);
                    break;
                }
            }
        });
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

    }

}
