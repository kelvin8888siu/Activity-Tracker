package ActivityTracker.API;

import ActivityTracker.DAO.ActivitySegmentTypesDao;
import ActivityTracker.DAO.ActivitySummaryDao;
import ActivityTracker.model.ActivitySegmentTypes;
import ActivityTracker.model.ActivitySummary;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Service
public class ActivitySegmentTypesApiDelegateImpl implements ActivitySegmentTypesApiDelegate{

    @Override
    public ResponseEntity<Void> createActivitySegmentType(ActivitySegmentTypes activitySegmentTypes) {
        ActivitySegmentTypesDao test = new ActivitySegmentTypesDao();
        try {
            test.create(activitySegmentTypes);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }

    @Override
    public ResponseEntity<List<ActivitySegmentTypes>> getAllActivitySegmentTypes() {
        ActivitySegmentTypesDao test = new ActivitySegmentTypesDao();
        ArrayList<ActivitySegmentTypes> activitySegmentTypes = null;
        try {
            activitySegmentTypes = test.getAllActivitySegmentTypes();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return ResponseEntity.ok(activitySegmentTypes);
    }
}
