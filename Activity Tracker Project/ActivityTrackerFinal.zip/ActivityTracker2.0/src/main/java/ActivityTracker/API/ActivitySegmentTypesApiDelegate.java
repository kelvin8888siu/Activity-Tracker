package ActivityTracker.API;

import ActivityTracker.model.ActivitySegmentTypes;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.NativeWebRequest;

import java.util.List;
import java.util.Optional;

/**
 * A delegate to be called by the {@link ActivitySegmentTypesApiController}}.
 * Implement this interface with a {@link org.springframework.stereotype.Service} annotated class.
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2021-08-05T15:58:24.603184-04:00[America/Toronto]")

public interface ActivitySegmentTypesApiDelegate {

    default Optional<NativeWebRequest> getRequest() {
        return Optional.empty();
    }

    /**
     * POST /activitySegmentTypes : creates an activity segment type
     *
     * @param activitySegmentTypes  (required)
     * @return Successfully created. (status code 200)
     *         or Did not work. (status code 400)
     * @see ActivitySegmentTypesApi#createActivitySegmentType
     */
    default ResponseEntity<Void> createActivitySegmentType(ActivitySegmentTypes activitySegmentTypes) {
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

    }

    /**
     * GET /activitySegmentTypes : obtains all activity segment types
     * gets all activity segment types
     *
     * @return Returned all activity segment types (status code 200)
     *         or Did not work. (status code 400)
     * @see ActivitySegmentTypesApi#getAllActivitySegmentTypes
     */
    default ResponseEntity<List<ActivitySegmentTypes>> getAllActivitySegmentTypes() {
        getRequest().ifPresent(request -> {
            for (MediaType mediaType: MediaType.parseMediaTypes(request.getHeader("Accept"))) {
                if (mediaType.isCompatibleWith(MediaType.valueOf("application/json"))) {
                    String exampleString = "{ \"duration\" : 1.4658129, \"activity\" : \"activity\", \"distance\" : 5.962134, \"segmentId\" : 6, \"startTime\" : \"2000-01-23T04:56:07.000+00:00\", \"endTime\" : \"2000-01-23T04:56:07.000+00:00\", \"calories\" : 5.637377, \"steps\" : 2, \"activitySegmentTypesId\" : 0 }";
                    ApiUtil.setExampleResponse(request, "application/json", exampleString);
                    break;
                }
            }
        });
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

    }

}
