package ActivityTracker.API;

import ActivityTracker.DAO.RecordsDao;
import ActivityTracker.DAO.SegmentTypesDao;
import ActivityTracker.model.Records;
import ActivityTracker.model.SegmentTypes;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Service
public class SegmentTypesApiDelegateImpl implements SegmentTypesApiDelegate{

    @Override
    public ResponseEntity<Void> createSegmentTypes(SegmentTypes segmentTypes) {
        SegmentTypesDao test = new SegmentTypesDao();
        try {
            test.create(segmentTypes);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }

    @Override
    public ResponseEntity<List<SegmentTypes>> getAllSegmentTypes() {
        SegmentTypesDao test = new SegmentTypesDao();
        ArrayList<SegmentTypes> segmentTypes = null;
        try {
            segmentTypes = test.getAllSegmentTypes();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return ResponseEntity.ok(segmentTypes);
    }

}
