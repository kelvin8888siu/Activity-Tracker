package ActivityTracker.API;

import ActivityTracker.DAO.ActivitySummaryDao;
import ActivityTracker.DAO.RecordsDao;
import ActivityTracker.model.ActivitySummary;
import ActivityTracker.model.Records;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Service
public class ActivitySummaryApiDelegateImpl implements ActivitySummaryApiDelegate{

    @Override
    public ResponseEntity<Void> createActivitySummary(ActivitySummary activitySummary) {
        ActivitySummaryDao test = new ActivitySummaryDao();
        try {
            test.create(activitySummary);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }

    @Override
    public ResponseEntity<List<ActivitySummary>> getAllActivitiesByDate(String date) {
        ActivitySummaryDao test = new ActivitySummaryDao();
        ArrayList<ActivitySummary> activitySummary = null;
        date = date.substring(1,11);

        try {
            activitySummary = test.getActivitySummaryByDate(Date.valueOf(date));
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return ResponseEntity.ok(activitySummary);
    }

    @Override
    public ResponseEntity<List<ActivitySummary>> getAllActivitySummary() {
        ActivitySummaryDao test = new ActivitySummaryDao();
        ArrayList<ActivitySummary> activitySummary = null;
        try {
            activitySummary = test.getAllActivitySummary();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return ResponseEntity.ok(activitySummary);
    }

    @Override
    public ResponseEntity<List<ActivitySummary>> getSpecificActivitySummaryByDate(String date, String activity) {
        ActivitySummaryDao test = new ActivitySummaryDao();
        ArrayList<ActivitySummary> activitySummary = null;
        date = date.substring(1,11);
        activity = activity.substring(1, (activity.length()-1));
        try {
            activitySummary = test.getSpecificActivitySummaryByDate(Date.valueOf(date), activity);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return ResponseEntity.ok(activitySummary);
    }
}
