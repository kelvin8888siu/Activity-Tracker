package ActivityTracker.API;

import ActivityTracker.DAO.RecordsDao;
import ActivityTracker.DAO.SummaryDao;
import ActivityTracker.model.Records;
import ActivityTracker.model.Summary;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Service
public class SummaryApiDelegateImpl implements SummaryApiDelegate {

    @Override
    public ResponseEntity<Void> createSummary(Summary summary) {
        SummaryDao sDao = new SummaryDao();
        try {
            sDao.create(summary);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }


    @Override
    public ResponseEntity<List<Summary>> getAllSummary() {
        SummaryDao sDao = new SummaryDao();
        ArrayList<Summary> summary = null;
        try {
            summary = sDao.getAllSummary();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return ResponseEntity.ok(summary);
        }
}
