package ActivityTracker.API;

import ActivityTracker.DAO.PlaceDao;
import ActivityTracker.DAO.RecordsDao;
import ActivityTracker.model.Place;
import ActivityTracker.model.Records;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Service
public class PlacesApiDelegateImpl implements PlacesApiDelegate {

    @Override
    public ResponseEntity<Void> createPlace(Place place) {
        PlaceDao test = new PlaceDao();
        try {
           test.create(place);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }

    @Override
    public ResponseEntity<List<Place>> getAllPlaces() {
        PlaceDao test = new PlaceDao();
        ArrayList<Place> place = null;
        try {
            place = test.getAllPlaces();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return ResponseEntity.ok(place);
    }
}
