package ActivityTracker.API;

import ActivityTracker.DAO.RecordsDao;
import ActivityTracker.model.Records;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Service
public class RecordsApiDelegateImpl implements RecordsApiDelegate {

    @Override
    public ResponseEntity<Void> createRecord(Records records) {
        RecordsDao test = new RecordsDao();
        try {
            test.create(records);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;

    }

    @Override
    public ResponseEntity<Void> deleteRecord(String date) {
        RecordsDao test = new RecordsDao();
        date = date.substring(1,11);
        try {
            Records r = test.getRecord(Date.valueOf(date));
            test.delete(r);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }


    @Override
    public ResponseEntity<List<Records>> getAllRecords() {
        RecordsDao test = new RecordsDao();
        ArrayList<Records> records = null;
        try {
            records = test.getAllRecords();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return ResponseEntity.ok(records);
    }
}
