package ActivityTracker.API;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import java.util.Optional;
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2021-08-05T15:58:24.603184-04:00[America/Toronto]")

@Controller
@RequestMapping("${openapi.activityTracker.base-path:}")
public class SummaryApiController implements SummaryApi {

    private final SummaryApiDelegate delegate;

    public SummaryApiController(@org.springframework.beans.factory.annotation.Autowired(required = false) SummaryApiDelegate delegate) {
        this.delegate = Optional.ofNullable(delegate).orElse(new SummaryApiDelegate() {});
    }

    @Override
    public SummaryApiDelegate getDelegate() {
        return delegate;
    }

}
