package ActivityTracker.API;

import ActivityTracker.model.Records;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.NativeWebRequest;

import java.util.List;
import java.util.Optional;

/**
 * A delegate to be called by the {@link RecordsApiController}}.
 * Implement this interface with a {@link org.springframework.stereotype.Service} annotated class.
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2021-08-05T15:58:24.603184-04:00[America/Toronto]")

public interface RecordsApiDelegate {

    default Optional<NativeWebRequest> getRequest() {
        return Optional.empty();
    }

    /**
     * POST /records : creates a record
     *
     * @param records  (required)
     * @return Successfully created. (status code 200)
     *         or Did not work. (status code 400)
     * @see RecordsApi#createRecord
     */
    default ResponseEntity<Void> createRecord(Records records) {
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

    }

    /**
     * DELETE /records/{date} : Delete record by date
     * Deletes all information pertaining to a record by date
     *
     * @param date date of record (required)
     * @return successful operation (status code 200)
     *         or Invalid date supplied (status code 400)
     * @see RecordsApi#deleteRecord
     */
    default ResponseEntity<Void> deleteRecord(String date) {
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

    }

    /**
     * GET /records : obtains all records
     * gets all the records
     *
     * @return Returned all records. (status code 200)
     *         or Did not work. (status code 400)
     * @see RecordsApi#getAllRecords
     */
    default ResponseEntity<List<Records>> getAllRecords() {
        getRequest().ifPresent(request -> {
            for (MediaType mediaType: MediaType.parseMediaTypes(request.getHeader("Accept"))) {
                if (mediaType.isCompatibleWith(MediaType.valueOf("application/json"))) {
                    String exampleString = "{ \"date\" : \"2000-01-23\", \"lastupdated\" : \"2000-01-23T04:56:07.000+00:00\", \"calorieIdle\" : 0 }";
                    ApiUtil.setExampleResponse(request, "application/json", exampleString);
                    break;
                }
            }
        });
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

    }

}
