package ActivityTracker.API;

import ActivityTracker.DAO.ActivityPlacesDao;
import ActivityTracker.DAO.ActivitySummaryDao;
import ActivityTracker.model.ActivityPlaces;
import ActivityTracker.model.ActivitySummary;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Service
public class ActivityPlacesApiDelegateImpl implements ActivityPlacesApiDelegate{

    @Override
    public ResponseEntity<Void> createActivityPlace(ActivityPlaces activityPlaces) {
        ActivityPlacesDao test = new ActivityPlacesDao();
        try {
            test.create(activityPlaces);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }

    @Override
    public ResponseEntity<List<ActivityPlaces>> getAllActivityPlaces() {
        ActivityPlacesDao test = new ActivityPlacesDao();
        ArrayList<ActivityPlaces> activityPlaces = null;
        try {
            activityPlaces = test.getAllActivityPlaces();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return ResponseEntity.ok(activityPlaces);
    }
}
