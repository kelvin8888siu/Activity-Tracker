package ActivityTracker.model;

import java.util.ArrayList;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Place
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2021-08-05T15:58:24.603184-04:00[America/Toronto]")

public class Place   {
  @JsonProperty("placeTypeId")
  private Integer placeTypeId;

  @JsonProperty("segmentId")
  private Integer segmentId;

  @JsonProperty("name")
  private String name;

  @JsonProperty("placeType")
  private String placeType;

  @JsonProperty("placeId")
  private int placeId;

  private ArrayList<ActivityPlaces> activities;

  public Place(Integer placeTypeId, Integer segmentId, String name, String placeType, int placeId) {
    this.placeTypeId = placeTypeId;
    this.segmentId = segmentId;
    this.name = name;
    this.placeType = placeType;
    this.placeId = placeId;
  }

  public Place(Integer segmentId, String name, String placeType, int placeId) {
    this.segmentId = segmentId;
    this.name = name;
    this.placeType = placeType;
    this.placeId = placeId;
  }

  public Place(){}

  public int getPlaceId() {
    return placeId;
  }

  public ArrayList<ActivityPlaces> getActivities() {
    return activities;
  }

  public void setPlaceId(int placeId) {
    this.placeId = placeId;
  }

  public void setActivities(ArrayList<ActivityPlaces> activities) {
    this.activities = activities;
  }

  public Place placeTypeId(Integer placeTypeId) {
    this.placeTypeId = placeTypeId;
    return this;
  }

  /**
   * Get placeTypeId
   * @return placeTypeId
   */
  @ApiModelProperty(value = "")


  public Integer getPlaceTypeId() {
    return placeTypeId;
  }

  public void setPlaceTypeId(Integer placeTypeId) {
    this.placeTypeId = placeTypeId;
  }

  public Place segmentId(Integer segmentId) {
    this.segmentId = segmentId;
    return this;
  }

  /**
   * Get segmentId
   * @return segmentId
   */
  @ApiModelProperty(value = "")


  public Integer getSegmentId() {
    return segmentId;
  }

  public void setSegmentId(Integer segmentId) {
    this.segmentId = segmentId;
  }

  public Place name(String name) {
    this.name = name;
    return this;
  }

  /**
   * Get name
   * @return name
   */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Place placeType(String placeType) {
    this.placeType = placeType;
    return this;
  }

  /**
   * Get placeType
   * @return placeType
   */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public String getPlaceType() {
    return placeType;
  }

  public void setPlaceType(String placeType) {
    this.placeType = placeType;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Place place = (Place) o;
    return Objects.equals(this.placeTypeId, place.placeTypeId) &&
            Objects.equals(this.segmentId, place.segmentId) &&
            Objects.equals(this.name, place.name) &&
            Objects.equals(this.placeType, place.placeType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(placeTypeId, segmentId, name, placeType);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Place {\n");

    sb.append("    placeTypeId: ").append(toIndentedString(placeTypeId)).append("\n");
    sb.append("    segmentId: ").append(toIndentedString(segmentId)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    placeType: ").append(toIndentedString(placeType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

