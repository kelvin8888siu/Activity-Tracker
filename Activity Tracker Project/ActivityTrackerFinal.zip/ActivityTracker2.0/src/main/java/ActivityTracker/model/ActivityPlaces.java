package ActivityTracker.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.time.OffsetDateTime;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ActivityPlaces
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2021-08-05T15:58:24.603184-04:00[America/Toronto]")

public class ActivityPlaces   {
  @JsonProperty("activityPlaceId")
  private Integer activityPlaceId;

  @JsonProperty("placeTypeId")
  private Integer placeTypeId;

  @JsonProperty("startTime")
  private OffsetDateTime startTime;

  @JsonProperty("endTime")
  private OffsetDateTime endTime;

  @JsonProperty("activity")
  private String activity;

  @JsonProperty("duration")
  private Float duration;

  @JsonProperty("distance")
  private Float distance;

  @JsonProperty("calories")
  private Float calories;

  @JsonProperty("steps")
  private Integer steps;

  public ActivityPlaces activityPlaceId(Integer activityPlaceId) {
    this.activityPlaceId = activityPlaceId;
    return this;
  }

  public ActivityPlaces(Integer activityPlaceId, Integer placeTypeId, OffsetDateTime startTime, OffsetDateTime endTime, String activity, Float duration, Float distance, Float calories, Integer steps) {
    this.activityPlaceId = activityPlaceId;
    this.placeTypeId = placeTypeId;
    this.startTime = startTime;
    this.endTime = endTime;
    this.activity = activity;
    this.duration = duration;
    this.distance = distance;
    this.calories = calories;
    this.steps = steps;
  }

  public ActivityPlaces(Integer placeTypeId, OffsetDateTime startTime, OffsetDateTime endTime, String activity, Float duration, Float distance, Float calories, Integer steps) {
    this.placeTypeId = placeTypeId;
    this.startTime = startTime;
    this.endTime = endTime;
    this.activity = activity;
    this.duration = duration;
    this.distance = distance;
    this.calories = calories;
    this.steps = steps;
  }

  public ActivityPlaces() {}

  /**
   * Get activityPlaceId
   * @return activityPlaceId
   */
  @ApiModelProperty(value = "")


  public Integer getActivityPlaceId() {
    return activityPlaceId;
  }

  public void setActivityPlaceId(Integer activityPlaceId) {
    this.activityPlaceId = activityPlaceId;
  }

  public ActivityPlaces placeTypeId(Integer placeTypeId) {
    this.placeTypeId = placeTypeId;
    return this;
  }

  /**
   * Get placeTypeId
   * @return placeTypeId
   */
  @ApiModelProperty(value = "")


  public Integer getPlaceTypeId() {
    return placeTypeId;
  }

  public void setPlaceTypeId(Integer placeTypeId) {
    this.placeTypeId = placeTypeId;
  }

  public ActivityPlaces startTime(OffsetDateTime startTime) {
    this.startTime = startTime;
    return this;
  }

  /**
   * Get startTime
   * @return startTime
   */
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public OffsetDateTime getStartTime() {
    return startTime;
  }

  public void setStartTime(OffsetDateTime startTime) {
    this.startTime = startTime;
  }

  public ActivityPlaces endTime(OffsetDateTime endTime) {
    this.endTime = endTime;
    return this;
  }

  /**
   * Get endTime
   * @return endTime
   */
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public OffsetDateTime getEndTime() {
    return endTime;
  }

  public void setEndTime(OffsetDateTime endTime) {
    this.endTime = endTime;
  }

  public ActivityPlaces activity(String activity) {
    this.activity = activity;
    return this;
  }

  /**
   * Get activity
   * @return activity
   */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public String getActivity() {
    return activity;
  }

  public void setActivity(String activity) {
    this.activity = activity;
  }

  public ActivityPlaces duration(Float duration) {
    this.duration = duration;
    return this;
  }

  /**
   * Get duration
   * @return duration
   */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public Float getDuration() {
    return duration;
  }

  public void setDuration(Float duration) {
    this.duration = duration;
  }

  public ActivityPlaces distance(Float distance) {
    this.distance = distance;
    return this;
  }

  /**
   * Get distance
   * @return distance
   */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public Float getDistance() {
    return distance;
  }

  public void setDistance(Float distance) {
    this.distance = distance;
  }

  public ActivityPlaces calories(Float calories) {
    this.calories = calories;
    return this;
  }

  /**
   * Get calories
   * @return calories
   */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public Float getCalories() {
    return calories;
  }

  public void setCalories(Float calories) {
    this.calories = calories;
  }

  public ActivityPlaces steps(Integer steps) {
    this.steps = steps;
    return this;
  }

  /**
   * Get steps
   * @return steps
   */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public Integer getSteps() {
    return steps;
  }

  public void setSteps(Integer steps) {
    this.steps = steps;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ActivityPlaces activityPlaces = (ActivityPlaces) o;
    return Objects.equals(this.activityPlaceId, activityPlaces.activityPlaceId) &&
            Objects.equals(this.placeTypeId, activityPlaces.placeTypeId) &&
            Objects.equals(this.startTime, activityPlaces.startTime) &&
            Objects.equals(this.endTime, activityPlaces.endTime) &&
            Objects.equals(this.activity, activityPlaces.activity) &&
            Objects.equals(this.duration, activityPlaces.duration) &&
            Objects.equals(this.distance, activityPlaces.distance) &&
            Objects.equals(this.calories, activityPlaces.calories) &&
            Objects.equals(this.steps, activityPlaces.steps);
  }

  @Override
  public int hashCode() {
    return Objects.hash(activityPlaceId, placeTypeId, startTime, endTime, activity, duration, distance, calories, steps);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ActivityPlaces {\n");

    sb.append("    activityPlaceId: ").append(toIndentedString(activityPlaceId)).append("\n");
    sb.append("    placeTypeId: ").append(toIndentedString(placeTypeId)).append("\n");
    sb.append("    startTime: ").append(toIndentedString(startTime)).append("\n");
    sb.append("    endTime: ").append(toIndentedString(endTime)).append("\n");
    sb.append("    activity: ").append(toIndentedString(activity)).append("\n");
    sb.append("    duration: ").append(toIndentedString(duration)).append("\n");
    sb.append("    distance: ").append(toIndentedString(distance)).append("\n");
    sb.append("    calories: ").append(toIndentedString(calories)).append("\n");
    sb.append("    steps: ").append(toIndentedString(steps)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

