package ActivityTracker.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.time.OffsetDateTime;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ActivitySegmentTypes
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2021-08-05T15:58:24.603184-04:00[America/Toronto]")

public class ActivitySegmentTypes   {
  @JsonProperty("activitySegmentTypesId")
  private Integer activitySegmentTypesId;

  @JsonProperty("segmentId")
  private Integer segmentId;

  @JsonProperty("startTime")
  private OffsetDateTime startTime;

  @JsonProperty("endTime")
  private OffsetDateTime endTime;

  @JsonProperty("activity")
  private String activity;

  @JsonProperty("duration")
  private Float duration;

  @JsonProperty("distance")
  private Float distance;

  @JsonProperty("calories")
  private Float calories;

  @JsonProperty("steps")
  private Integer steps;

  public ActivitySegmentTypes(Integer activitySegmentTypesId, Integer segmentId, OffsetDateTime startTime, OffsetDateTime endTime, String activity, Float duration, Float distance, Float calories, Integer steps) {
    this.activitySegmentTypesId = activitySegmentTypesId;
    this.segmentId = segmentId;
    this.startTime = startTime;
    this.endTime = endTime;
    this.activity = activity;
    this.duration = duration;
    this.distance = distance;
    this.calories = calories;
    this.steps = steps;
  }

  public ActivitySegmentTypes(Integer segmentId, OffsetDateTime startTime, OffsetDateTime endTime, String activity, Float duration, Float distance, Float calories, Integer steps) {
    this.segmentId = segmentId;
    this.startTime = startTime;
    this.endTime = endTime;
    this.activity = activity;
    this.duration = duration;
    this.distance = distance;
    this.calories = calories;
    this.steps = steps;
  }

  public ActivitySegmentTypes activitySegmentTypesId(Integer activitySegmentTypesId) {
    this.activitySegmentTypesId = activitySegmentTypesId;
    return this;
  }

  /**
   * Get activitySegmentTypesId
   * @return activitySegmentTypesId
   */
  @ApiModelProperty(value = "")


  public Integer getActivitySegmentTypesId() {
    return activitySegmentTypesId;
  }

  public void setActivitySegmentTypesId(Integer activitySegmentTypesId) {
    this.activitySegmentTypesId = activitySegmentTypesId;
  }

  public ActivitySegmentTypes segmentId(Integer segmentId) {
    this.segmentId = segmentId;
    return this;
  }

  public ActivitySegmentTypes() {}

  /**
   * Get segmentId
   * @return segmentId
   */
  @ApiModelProperty(value = "")


  public Integer getSegmentId() {
    return segmentId;
  }

  public void setSegmentId(Integer segmentId) {
    this.segmentId = segmentId;
  }

  public ActivitySegmentTypes startTime(OffsetDateTime startTime) {
    this.startTime = startTime;
    return this;
  }

  /**
   * Get startTime
   * @return startTime
   */
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public OffsetDateTime getStartTime() {
    return startTime;
  }

  public void setStartTime(OffsetDateTime startTime) {
    this.startTime = startTime;
  }

  public ActivitySegmentTypes endTime(OffsetDateTime endTime) {
    this.endTime = endTime;
    return this;
  }

  /**
   * Get endTime
   * @return endTime
   */
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public OffsetDateTime getEndTime() {
    return endTime;
  }

  public void setEndTime(OffsetDateTime endTime) {
    this.endTime = endTime;
  }

  public ActivitySegmentTypes activity(String activity) {
    this.activity = activity;
    return this;
  }

  /**
   * Get activity
   * @return activity
   */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public String getActivity() {
    return activity;
  }

  public void setActivity(String activity) {
    this.activity = activity;
  }

  public ActivitySegmentTypes duration(Float duration) {
    this.duration = duration;
    return this;
  }

  /**
   * Get duration
   * @return duration
   */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public Float getDuration() {
    return duration;
  }

  public void setDuration(Float duration) {
    this.duration = duration;
  }

  public ActivitySegmentTypes distance(Float distance) {
    this.distance = distance;
    return this;
  }

  /**
   * Get distance
   * @return distance
   */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public Float getDistance() {
    return distance;
  }

  public void setDistance(Float distance) {
    this.distance = distance;
  }

  public ActivitySegmentTypes calories(Float calories) {
    this.calories = calories;
    return this;
  }

  /**
   * Get calories
   * @return calories
   */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public Float getCalories() {
    return calories;
  }

  public void setCalories(Float calories) {
    this.calories = calories;
  }

  public ActivitySegmentTypes steps(Integer steps) {
    this.steps = steps;
    return this;
  }

  /**
   * Get steps
   * @return steps
   */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public Integer getSteps() {
    return steps;
  }

  public void setSteps(Integer steps) {
    this.steps = steps;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ActivitySegmentTypes activitySegmentTypes = (ActivitySegmentTypes) o;
    return Objects.equals(this.activitySegmentTypesId, activitySegmentTypes.activitySegmentTypesId) &&
            Objects.equals(this.segmentId, activitySegmentTypes.segmentId) &&
            Objects.equals(this.startTime, activitySegmentTypes.startTime) &&
            Objects.equals(this.endTime, activitySegmentTypes.endTime) &&
            Objects.equals(this.activity, activitySegmentTypes.activity) &&
            Objects.equals(this.duration, activitySegmentTypes.duration) &&
            Objects.equals(this.distance, activitySegmentTypes.distance) &&
            Objects.equals(this.calories, activitySegmentTypes.calories) &&
            Objects.equals(this.steps, activitySegmentTypes.steps);
  }

  @Override
  public int hashCode() {
    return Objects.hash(activitySegmentTypesId, segmentId, startTime, endTime, activity, duration, distance, calories, steps);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ActivitySegmentTypes {\n");

    sb.append("    activitySegmentTypesId: ").append(toIndentedString(activitySegmentTypesId)).append("\n");
    sb.append("    segmentId: ").append(toIndentedString(segmentId)).append("\n");
    sb.append("    startTime: ").append(toIndentedString(startTime)).append("\n");
    sb.append("    endTime: ").append(toIndentedString(endTime)).append("\n");
    sb.append("    activity: ").append(toIndentedString(activity)).append("\n");
    sb.append("    duration: ").append(toIndentedString(duration)).append("\n");
    sb.append("    distance: ").append(toIndentedString(distance)).append("\n");
    sb.append("    calories: ").append(toIndentedString(calories)).append("\n");
    sb.append("    steps: ").append(toIndentedString(steps)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

