package ActivityTracker.model;

import java.util.ArrayList;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * SegmentTypes
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2021-08-05T15:58:24.603184-04:00[America/Toronto]")

public class SegmentTypes   {
  @JsonProperty("segmentId")
  private Integer segmentId;

  @JsonProperty("date")
  private LocalDate date;

  @JsonProperty("segmentType")
  private String segmentType;

  @JsonProperty("startTime")
  private OffsetDateTime startTime;

  @JsonProperty("endTime")
  private OffsetDateTime endTime;

  @JsonProperty("lastUpdate")
  private LocalDate lastUpdate;

  private ArrayList<ActivitySegmentTypes> activities;

  public SegmentTypes(Integer segmentId, LocalDate date, String segmentType, OffsetDateTime startTime, OffsetDateTime endTime, LocalDate lastUpdate) {
    this.segmentId = segmentId;
    this.date = date;
    this.segmentType = segmentType;
    this.startTime = startTime;
    this.endTime = endTime;
    this.lastUpdate = lastUpdate;
  }

  public SegmentTypes(LocalDate date, String segmentType, OffsetDateTime startTime, OffsetDateTime endTime, LocalDate lastUpdate) {
    this.date = date;
    this.segmentType = segmentType;
    this.startTime = startTime;
    this.endTime = endTime;
    this.lastUpdate = lastUpdate;
  }

  public SegmentTypes(){}

  public ArrayList<ActivitySegmentTypes> getActivities() {
    return activities;
  }

  public void setActivities(ArrayList<ActivitySegmentTypes> activities) {
    this.activities = activities;
  }

  public SegmentTypes segmentId(Integer segmentId) {
    this.segmentId = segmentId;
    return this;
  }

  /**
   * Get segmentId
   * @return segmentId
   */
  @ApiModelProperty(value = "")


  public Integer getSegmentId() {
    return segmentId;
  }

  public void setSegmentId(Integer segmentId) {
    this.segmentId = segmentId;
  }

  public SegmentTypes date(LocalDate date) {
    this.date = date;
    return this;
  }

  /**
   * Get date
   * @return date
   */
  @ApiModelProperty(value = "")

  @Valid

  public LocalDate getDate() {
    return date;
  }

  public void setDate(LocalDate date) {
    this.date = date;
  }

  public SegmentTypes segmentType(String segmentType) {
    this.segmentType = segmentType;
    return this;
  }

  /**
   * Get segmentType
   * @return segmentType
   */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public String getSegmentType() {
    return segmentType;
  }

  public void setSegmentType(String segmentType) {
    this.segmentType = segmentType;
  }

  public SegmentTypes startTime(OffsetDateTime startTime) {
    this.startTime = startTime;
    return this;
  }

  /**
   * Get startTime
   * @return startTime
   */
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public OffsetDateTime getStartTime() {
    return startTime;
  }

  public void setStartTime(OffsetDateTime startTime) {
    this.startTime = startTime;
  }

  public SegmentTypes endTime(OffsetDateTime endTime) {
    this.endTime = endTime;
    return this;
  }

  /**
   * Get endTime
   * @return endTime
   */
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public OffsetDateTime getEndTime() {
    return endTime;
  }

  public void setEndTime(OffsetDateTime endTime) {
    this.endTime = endTime;
  }

  public SegmentTypes lastUpdate(LocalDate lastUpdate) {
    this.lastUpdate = lastUpdate;
    return this;
  }

  /**
   * Get lastUpdate
   * @return lastUpdate
   */
  @ApiModelProperty(value = "")

  @Valid

  public LocalDate getLastUpdate() {
    return lastUpdate;
  }

  public void setLastUpdate(LocalDate lastUpdate) {
    this.lastUpdate = lastUpdate;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SegmentTypes segmentTypes = (SegmentTypes) o;
    return Objects.equals(this.segmentId, segmentTypes.segmentId) &&
            Objects.equals(this.date, segmentTypes.date) &&
            Objects.equals(this.segmentType, segmentTypes.segmentType) &&
            Objects.equals(this.startTime, segmentTypes.startTime) &&
            Objects.equals(this.endTime, segmentTypes.endTime) &&
            Objects.equals(this.lastUpdate, segmentTypes.lastUpdate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(segmentId, date, segmentType, startTime, endTime, lastUpdate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SegmentTypes {\n");

    sb.append("    segmentId: ").append(toIndentedString(segmentId)).append("\n");
    sb.append("    date: ").append(toIndentedString(date)).append("\n");
    sb.append("    segmentType: ").append(toIndentedString(segmentType)).append("\n");
    sb.append("    startTime: ").append(toIndentedString(startTime)).append("\n");
    sb.append("    endTime: ").append(toIndentedString(endTime)).append("\n");
    sb.append("    lastUpdate: ").append(toIndentedString(lastUpdate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

