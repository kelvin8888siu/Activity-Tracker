package ActivityTracker.model;

import java.util.ArrayList;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import java.time.LocalDate;
import javax.validation.Valid;

/**
 * Summary
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2021-08-05T15:58:24.603184-04:00[America/Toronto]")

public class Summary   {
  @JsonProperty("summaryId")
  private Integer summaryId;

  @JsonProperty("date")
  private LocalDate date;

  private ArrayList<ActivitySummary> activities;

  public Summary(Integer summaryId, LocalDate date) {
    this.summaryId = summaryId;
    this.date = date;
  }

  public Summary() {}

  public Summary(LocalDate date) {
    this.date = date;
  }

  public ArrayList<ActivitySummary> getActivities() {
    return activities;
  }

  public void setActivities(ArrayList<ActivitySummary> activities) {
    this.activities = activities;
  }

  public Summary summaryId(Integer summaryId) {
    this.summaryId = summaryId;
    return this;
  }

  /**
   * Get summaryId
   * @return summaryId
   */
  @ApiModelProperty(value = "")


  public Integer getSummaryId() {
    return summaryId;
  }

  public void setSummaryId(Integer summaryId) {
    this.summaryId = summaryId;
  }

  public Summary date(LocalDate date) {
    this.date = date;
    return this;
  }

  /**
   * Get date
   * @return date
   */
  @ApiModelProperty(value = "")

  @Valid

  public LocalDate getDate() {
    return date;
  }

  public void setDate(LocalDate date) {
    this.date = date;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Summary summary = (Summary) o;
    return Objects.equals(this.summaryId, summary.summaryId) &&
            Objects.equals(this.date, summary.date);
  }

  @Override
  public int hashCode() {
    return Objects.hash(summaryId, date);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Summary {\n");

    sb.append("    summaryId: ").append(toIndentedString(summaryId)).append("\n");
    sb.append("    date: ").append(toIndentedString(date)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

